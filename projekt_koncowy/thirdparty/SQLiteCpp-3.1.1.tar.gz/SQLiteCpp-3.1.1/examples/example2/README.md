SQLiteCpp_Example demonstrates how to use SQLiteCpp as a subdirectory of a CMake project.

See https://github.com/SRombauts/SQLiteCpp_Example